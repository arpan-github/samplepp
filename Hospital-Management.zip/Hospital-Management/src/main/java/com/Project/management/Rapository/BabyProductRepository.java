package com.Project.management.Rapository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Project.management.Entity.MotherBabyCare;

@Repository
public interface BabyProductRepository extends JpaRepository<MotherBabyCare, Long> {

	@Query("SELECT m FROM MotherBabyCare m WHERE m.productname LIKE %?1%")
	public List<MotherBabyCare> search(String keyword);
}
