package com.Project.management.Service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.Project.management.Entity.Medicine;

public interface MedicineService {
	List<Medicine> getAllMedicine();
	void saveMedicine(Medicine medicine);
	Medicine getMedicineById(long medicine);
	void deleteMedicineById(long medicine);
	Page<Medicine> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);
	public List<Medicine> listAll(String keyword);
}
