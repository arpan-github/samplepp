package com.Project.management.Controller;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Project.management.Entity.PatientPrescription;
import com.Project.management.Helper.Massage;
import com.Project.management.Rapository.PatientPrescriptionRepo;
import com.Project.management.Service.PatientPrescriptionService;

@Controller
@RequestMapping("/doctor")
public class PatientPrescriptionCrontroller {

	@Autowired
	private PatientPrescriptionService patientPrescriptionService;

	@Autowired
	private PatientPrescriptionRepo PatientPrescriptionRepo;

	@GetMapping("/doctor-only")
	public String receptionLoging() {

		return "doctor-only";
	}

	@GetMapping("/Prescription")
	public String showPatientPrescriptionForm(Model model) {

		PatientPrescription patientPrescription = new PatientPrescription();
		model.addAttribute("patientPrescription", patientPrescription);
		return "Prescription";
	}

	@PostMapping("/savepatientPrescription")
	public String savepatientPrescription(
			@ModelAttribute("patientPrescription") PatientPrescription patientPrescription, HttpSession session,
			Model m) {
		// save employee to database
		if (patientPrescription == null) {
			session.setAttribute("message", new Massage("Successfilly Register !!", "alart-danger"));
			return "redirect:/doctor/Prescription";
		} else {
			try {
				patientPrescriptionService.savePatientPrescription(patientPrescription);
				session.setAttribute("message", new Massage("Successfilly Register !!", "alart-success"));
			} catch (Exception e) {
				e.printStackTrace();
				session.setAttribute("message", new Massage("Somthing went wring !!" + e.getMessage(), "alert-denger"));
			}
			return "redirect:/doctor/viewAllpatientPrescription";
		}
	}

	@GetMapping("/viewAllpatientPrescription")
	public String viewAllpatientPrescription(Model m, Principal principal) {

		List<PatientPrescription> patientPrescription = this.patientPrescriptionService.getAllPatientPrescription();
		m.addAttribute("allPatientPrescription", patientPrescription);
		m.addAttribute("title", "show all Patient Prescription");
		return "viewAll_Patient_Prescription";
	}

	@GetMapping("/view-single-patient-prescription/{patientprescriptionId}")
	public String showOne(@PathVariable("patientprescriptionId") long patientprescriptionId, Model m) {

		Optional<PatientPrescription> getone = this.PatientPrescriptionRepo.findById(patientprescriptionId);
		PatientPrescription PatientPrescription = getone.get();
		m.addAttribute("PatientPrescription", PatientPrescription);

		return "PDFPrescription";
	}
}
