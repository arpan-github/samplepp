package com.Project.management.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.management.Entity.Booking;
import com.Project.management.Rapository.BookingRepository;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingRepository bookingRepository;

	@Override
	public void saveBooking(Booking booking) {
		this.bookingRepository.save(booking);
	}

	@Override
	public Booking getBookingById(long id) {
		Optional<Booking> optional = bookingRepository.findById(id);
		Booking booking = null;
		if (optional.isPresent()) {
			booking = optional.get();
		} else {
			throw new RuntimeException(" medicine not found for id :: " + id);
		}
		return booking;
	}

	@Override
	public List<Booking> getAllpasent() {
		return bookingRepository.findAll();
	}

}
