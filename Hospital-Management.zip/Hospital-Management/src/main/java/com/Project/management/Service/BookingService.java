package com.Project.management.Service;

import java.util.List;

import com.Project.management.Entity.Booking;

public interface BookingService {

	void saveBooking(Booking booking);
	Booking getBookingById(long id);
	List<Booking> getAllpasent();
}
