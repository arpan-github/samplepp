package com.Project.management.Helper;

public class AboutSeeMore {

	public static String get10words(String desc) {
		String[] split = desc.split(" ");
		if (split.length > 10) {
			String res = "";
			for (int i = 0; i < 10; i++) {
				res = res + split[i]+" ";
			}
			return (res + "See More...");
		} else {
			return (desc + "See More...");
		}
	}
}
