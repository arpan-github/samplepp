package com.Project.management.Service;

import java.util.Date;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.management.Entity.CartItem;
import com.Project.management.Entity.Medicine;
import com.Project.management.Entity.ShoppingCart;
import com.Project.management.Rapository.ShoppingCartRepository;



@Service
public class ShoppingCartService {
	
	@Autowired
	private MedicineService medicineService;
	
	@Autowired
	private ShoppingCartRepository shoppingCartRepository;
	
	public ShoppingCart addShoppingCartFirstTime(Long id, String sessionToken, int quantity) {
		ShoppingCart shoppingCart=new ShoppingCart();
		CartItem cartItem=new CartItem();
		cartItem.setQuantity(quantity);
		cartItem.setDate(new Date());
		cartItem.setMedicine(medicineService.getMedicineById(id));
		shoppingCart.getItems().add(cartItem);
		shoppingCart.setSessionToken(sessionToken);
		return shoppingCartRepository.save(shoppingCart);
	}

	public ShoppingCart addToExistingShoppingCart(Long id, String sessionToken, int quantity) {

		ShoppingCart shoppingCart = shoppingCartRepository.findBySessionToken(sessionToken);
		Medicine p = medicineService.getMedicineById(id);
		Boolean productDoesExistInTheCart = false;
		if (shoppingCart != null) {
		    Set<CartItem> items = shoppingCart.getItems();
			for (CartItem item : items) {
				if (item.getMedicine().equals(p)) {
					productDoesExistInTheCart = true;
					item.setQuantity(item.getQuantity() + quantity);
					shoppingCart.setItems(items);
					return shoppingCartRepository.saveAndFlush(shoppingCart);  
				}
				
			}
		}
		if(!productDoesExistInTheCart && (shoppingCart != null))
		{
			CartItem cartItem1 = new CartItem();
			cartItem1.setDate(new Date());
			cartItem1.setQuantity(quantity);
			cartItem1.setMedicine(p);
			shoppingCart.getItems().add(cartItem1);
			return shoppingCartRepository.saveAndFlush(shoppingCart);
		}
		
		return this.addShoppingCartFirstTime(id, sessionToken, quantity);

	}
}
