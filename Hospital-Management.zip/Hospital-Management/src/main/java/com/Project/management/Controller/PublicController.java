package com.Project.management.Controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Project.management.Entity.Medicine;
import com.Project.management.Entity.MotherBabyCare;
import com.Project.management.Service.BabyProductService;
import com.Project.management.Service.MedicineService;

@Controller
@RequestMapping("/public")
public class PublicController {

	@Autowired
	private MedicineService medicineService;
	
	@Autowired
	private BabyProductService babyProductService;

	@GetMapping("/")
	public String home() {

		return "Home";
	}

	@GetMapping("/service")
	public String service() {

		return "service";
	}

	@GetMapping("/about-us")
	public String about() {

		return "about";
	}

	@GetMapping("/doctor")
	public String doctor() {

		return "doctor";
	}

	@GetMapping("/medicine-after-loging")
	public String viewAllMedicineNologing(Model m, Principal principal) {

		List<Medicine> allMedicine = this.medicineService.getAllMedicine();
		m.addAttribute("allMedicine", allMedicine);
		m.addAttribute("title", "show all Medicine");
		
		
		List<MotherBabyCare> allBabyProduct = this.babyProductService.getAllBabyProduct();
		m.addAttribute("allBabyProduct", allBabyProduct);
		m.addAttribute("title", "show all Medicine");
		return "after_loging_show_medicine";
	}
	
}
