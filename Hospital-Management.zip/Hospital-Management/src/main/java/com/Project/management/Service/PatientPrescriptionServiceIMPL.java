package com.Project.management.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.management.Entity.PatientPrescription;
import com.Project.management.Rapository.PatientPrescriptionRepo;

@Service
public class PatientPrescriptionServiceIMPL implements PatientPrescriptionService{

	@Autowired
	private PatientPrescriptionRepo patientPrescriptionRepo;

	@Override
	public void savePatientPrescription(PatientPrescription PatientPrescription) {
		this.patientPrescriptionRepo.save(PatientPrescription);
	}

	@Override
	public PatientPrescription getPatientPrescriptionById(long patientprescriptionId) {
		Optional<PatientPrescription> optional = patientPrescriptionRepo.findById(patientprescriptionId);
		PatientPrescription PatientPrescription = null;
		if (optional.isPresent()) {
			PatientPrescription = optional.get();
		} else {
			throw new RuntimeException(" medicine not found for id :: " + patientprescriptionId);
		}
		return PatientPrescription;
	}

	@Override
	public List<PatientPrescription> getAllPatientPrescription() {
		return patientPrescriptionRepo.findAll();
	}

}
