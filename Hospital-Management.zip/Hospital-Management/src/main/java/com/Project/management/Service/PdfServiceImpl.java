package com.Project.management.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import org.springframework.stereotype.Service;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;

@Service
public class PdfServiceImpl {

	public ByteArrayInputStream createpdf() {
		
		String title="This is pdf file format";
		String content="this is pdf";
		
		ByteArrayOutputStream out=new ByteArrayOutputStream();
		
		Document document=new Document();
		
		PdfWriter.getInstance(document, out);
		document.open();
		
		Font titlefont=FontFactory.getFont(FontFactory.HELVETICA_BOLD,20);
		Paragraph titlePara=new Paragraph(title,titlefont);
		titlePara.setAlignment(Element.ALIGN_CENTER);
		document.add(titlePara);
		
		
		Font parafont=FontFactory.getFont(FontFactory.HELVETICA,18);
		Paragraph paragraph=new Paragraph(content);
		paragraph.add(new Chunk("this is after create"));
		document.add(paragraph);
		
		document.close();
		
		return new ByteArrayInputStream(out.toByteArray());
	}
}
