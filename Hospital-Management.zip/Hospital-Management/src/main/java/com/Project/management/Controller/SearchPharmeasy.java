package com.Project.management.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Project.management.Entity.Medicine;
import com.Project.management.Service.MedicineService;

@Controller
public class SearchPharmeasy {

	@Autowired
	private MedicineService service;

	@RequestMapping("/search")
	public String view(Model model, @Param("keyword") String keyword) {
		List<Medicine> listProducts = service.listAll(keyword);
		model.addAttribute("listProducts", listProducts);
		model.addAttribute("keyword", keyword);
		return "medicine";
	}
}
