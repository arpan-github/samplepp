package com.Project.management.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.Project.management.Entity.MotherBabyCare;
import com.Project.management.Rapository.BabyProductRepository;

@Service
public class BabyProductServiceImpl implements BabyProductService {

	@Autowired
	private BabyProductRepository babyProductRepository;

	@Override
	public List<MotherBabyCare> getAllBabyProduct() {
		return babyProductRepository.findAll();
	}

	@Override
	public void saveBabyProduct(MotherBabyCare motherBabyCare) {
		this.babyProductRepository.save(motherBabyCare);
	}

	@Override
	public MotherBabyCare getBabyProductById(long babyproductId) {
		Optional<MotherBabyCare> optional = babyProductRepository.findById(babyproductId);
		MotherBabyCare motherBabyCare = null;
		if (optional.isPresent()) {
			motherBabyCare = optional.get();
		} else {
			throw new RuntimeException(" medicine not found for id :: " + babyproductId);
		}
		return motherBabyCare;
	}

	@Override
	public void deleteBabyProductById(long babyproductId) {
		this.babyProductRepository.deleteById(babyproductId);
	}

	@Override
	public Page<MotherBabyCare> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();

		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		return this.babyProductRepository.findAll(pageable);
	}

	@Override
	public List<MotherBabyCare> listAll(String keyword) {
		if (keyword != null) {
			return babyProductRepository.search(keyword);
		}
		return babyProductRepository.findAll();
	}
}
