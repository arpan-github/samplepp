package com.Project.management.Rapository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Project.management.Entity.Medicine;

@Repository
public interface MedicineRepository extends JpaRepository<Medicine, Long> {

	@Query("SELECT m FROM Medicine m WHERE m.medicinename LIKE %?1%")
	public List<Medicine> search(String keyword);
}
