package com.Project.management.Service;

import com.Project.management.Entity.User;

public interface UserService {

	void userData(User user);
	
}
