package com.Project.management.Controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.Project.management.Entity.Medicine;
import com.Project.management.Rapository.MedicineRepository;
import com.Project.management.Service.MedicineService;

@Controller
//@RequestMapping("/dealership")
public class MedicineController {

	@Autowired
	private MedicineService medicineService;

	@Autowired
	private MedicineRepository medicineRepository;

	@GetMapping("/addMedicineCat")
	public String addMedicineCat() {
		
		return "addMedicineCat";
	}
	
	@GetMapping("/showNewMedicineForm")
	public String showNewMedicineForm(Model model) {
		// create model attribute to bind form data
		Medicine medicine = new Medicine();
		model.addAttribute("employee", medicine);
		return "addMedicine_page";
	}

	@PostMapping("/saveMedicine")
	public String saveMedicine(@ModelAttribute("medicine") Medicine medicine,
			@RequestParam("profileImage") MultipartFile file) throws IOException {

		if (file.isEmpty()) {
			medicine.setImage("default.png");
		} else {
			medicine.setImage(file.getOriginalFilename());

			File savefile = new ClassPathResource("static/image").getFile();
			Path path = Paths.get(savefile.getAbsolutePath() + File.separator + file.getOriginalFilename());
			Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
		
		}

		// save employee to database
		medicineService.saveMedicine(medicine);
		return "redirect:/showNewMedicineForm";
	}

	@GetMapping("/viewAllMedicine")
	public String viewAllMedicine(Model m, Principal principal) {

		List<Medicine> allMedicine = this.medicineService.getAllMedicine();
		m.addAttribute("allMedicine", allMedicine);
		m.addAttribute("title", "show all Medicine");
		return "viewAll_Medicine";
	}

	@GetMapping("/view-single-medicin/{medicinid}")
	public String showOne(@PathVariable("medicinid") long medicinid, Model m) {

		Optional<Medicine> getone = this.medicineRepository.findById(medicinid);
		Medicine medicine = getone.get();
		m.addAttribute("medicine", medicine);

		return "single_Medicine";
	}

	@GetMapping("/delete/{medicinid}")
	public String deleteMedicine(@PathVariable("medicinid") long medicinid, Model m) {
		this.medicineService.deleteMedicineById(medicinid);

		return "redirect:/viewAllMedicine";
	}

	@GetMapping("/showFormForUpdate/{medicinid}")
	public String updateData(@PathVariable("medicinid") long medicinid,Model m) {
		Medicine medicine= medicineService.getMedicineById(medicinid);

		m.addAttribute("medicine", medicine);

		return "updateMedicine";
	}
}
