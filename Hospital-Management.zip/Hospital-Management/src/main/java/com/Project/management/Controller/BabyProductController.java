package com.Project.management.Controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.Project.management.Entity.Medicine;
import com.Project.management.Entity.MotherBabyCare;
import com.Project.management.Helper.Massage;
import com.Project.management.Rapository.BabyProductRepository;
import com.Project.management.Service.BabyProductService;
import com.Project.management.Service.MedicineService;

@Controller
public class BabyProductController {

	@Autowired
	private BabyProductRepository repo;

	@Autowired
	private BabyProductService babyProductService;

	@RequestMapping("/addMotherBabyCare")
	public String contactForm(Model model) {

		model.addAttribute("title", "Add Product");
		model.addAttribute("contact", new MotherBabyCare());
		return "addmotherBabyCare";
	}

	@PostMapping("/saveMotherBabyCare")
	public String contact(@ModelAttribute MotherBabyCare contact, @RequestParam("profileImage") MultipartFile file,
			Principal principal, HttpSession session) {

		try {

			// uploading Image
			if (file.isEmpty()) {
				contact.setProductImage("contact.png");
			} else {
				contact.setProductImage(file.getOriginalFilename());

				File savefile = new ClassPathResource("static/image").getFile();
				Path path = Paths.get(savefile.getAbsolutePath() + file.getOriginalFilename());
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			}

			repo.save(contact);
			System.out.println("save data to database" + contact);

			session.setAttribute("message", new Massage("Your contact is added....", "success"));
		} catch (Exception e) {
			e.printStackTrace();
			session.setAttribute("message", new Massage("Some went wrong!!!....", "Danger"));
		}
		return "/addMotherBabyCare";
	}

	@GetMapping("/viewAllBabyProduct")
	public String viewAllBabyProduct(Model m, Principal principal) {

		List<MotherBabyCare> allBabyProduct = this.babyProductService.getAllBabyProduct();
		m.addAttribute("allBabyProduct", allBabyProduct);
		m.addAttribute("title", "show all Medicine");
		return "viewAll_BabyProduct";
	}

	@GetMapping("/view-single-babyproduct/{babyproductId}")
	public String showOne(@PathVariable("babyproductId") long babyproductId, Model m) {

		Optional<MotherBabyCare> getone = this.repo.findById(babyproductId);
		MotherBabyCare oneBabyProduct = getone.get();
		m.addAttribute("oneBabyProduct", oneBabyProduct);

		return "single_BabyProduct";
	}

	@GetMapping("/deletebabyproduct/{babyproductId}")
	public String deleteBabyproduct(@PathVariable("babyproductId") long babyproductId, Model m) {
		// this.babyProductService.deleteBabyProductById(babyproductId);

		Optional<MotherBabyCare> prodactOptional = repo.findById(babyproductId);
		MotherBabyCare motherBabyCare = prodactOptional.get();
		this.repo.delete(motherBabyCare);
		return "redirect:/viewAllBabyProduct";
	}

	@PostMapping("/showbabyproductUpdate/{babyproductId}")
	public String updateData(@PathVariable("babyproductId")long babyproductId,Model m) {
		
        MotherBabyCare contact = repo.findById(babyproductId).get();
        m.addAttribute("contact", contact);
		return "updatebabyproduct";
	}

}
