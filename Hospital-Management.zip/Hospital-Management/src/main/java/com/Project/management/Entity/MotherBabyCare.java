package com.Project.management.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class MotherBabyCare {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long babyproductId;
	private String productname;
	private String productprice;
	private String productabout;
	private String productImage;

	public long getBabyproductId() {
		return babyproductId;
	}

	public void setBabyproductId(long babyproductId) {
		this.babyproductId = babyproductId;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public String getProductprice() {
		return productprice;
	}

	public void setProductprice(String productprice) {
		this.productprice = productprice;
	}

	public String getProductabout() {
		return productabout;
	}

	public void setProductabout(String productabout) {
		this.productabout = productabout;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

}
