package com.Project.management.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.Project.management.Entity.Medicine;
import com.Project.management.Rapository.MedicineRepository;

@Service
public class MedicineServiceImpl implements MedicineService {

	@Autowired
	private MedicineRepository medicineRepository;

	@Override
	public List<Medicine> getAllMedicine() {
		return medicineRepository.findAll();
	}

	@Override
	public void saveMedicine(Medicine medicine) {
		this.medicineRepository.save(medicine);
	}

	@Override
	public Medicine getMedicineById(long medicinid) {
		Optional<Medicine> optional = medicineRepository.findById(medicinid);
		Medicine medicine = null;
		if (optional.isPresent()) {
			medicine = optional.get();
		} else {
			throw new RuntimeException(" medicine not found for id :: " + medicinid);
		}
		return medicine;
	}

	@Override
	public void deleteMedicineById(long medicinid) {
		this.medicineRepository.deleteById(medicinid);
	}

	@Override
	public Page<Medicine> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();

		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		return this.medicineRepository.findAll(pageable);
	}

	@Override
	public List<Medicine> listAll(String keyword) {
        if (keyword != null) {
            return medicineRepository.search(keyword);
        }
        return medicineRepository.findAll();
    }
}
