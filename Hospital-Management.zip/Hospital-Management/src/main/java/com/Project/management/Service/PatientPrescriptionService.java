package com.Project.management.Service;

import java.util.List;

import com.Project.management.Entity.PatientPrescription;

public interface PatientPrescriptionService {

	void savePatientPrescription (PatientPrescription  PatientPrescription );
	PatientPrescription  getPatientPrescriptionById(long patientprescriptionId);
	List<PatientPrescription> getAllPatientPrescription();
}
