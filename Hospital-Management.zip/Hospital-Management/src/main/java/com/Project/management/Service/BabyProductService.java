package com.Project.management.Service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.Project.management.Entity.MotherBabyCare;

public interface BabyProductService {
	List<MotherBabyCare> getAllBabyProduct();
	void saveBabyProduct(MotherBabyCare motherBabyCare);
	MotherBabyCare getBabyProductById(long babyproductId);
	void deleteBabyProductById(long babyproductId);
	Page<MotherBabyCare> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);
	public List<MotherBabyCare> listAll(String keyword);
}
