package com.Project.management.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SuppressWarnings("deprecation")
@Configuration
@EnableWebSecurity
public class SecurityCfg extends WebSecurityConfigurerAdapter {

	@Bean
	public UserDetailsService getUserDetailsService() {
		return new UserDetailsServiceImpl();
	}

	@Bean
	public BCryptPasswordEncoder PasswordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public DaoAuthenticationProvider AuthenticationProvider() {
		DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();

		daoAuthenticationProvider.setUserDetailsService(getUserDetailsService());
		daoAuthenticationProvider.setPasswordEncoder(PasswordEncoder());

		return daoAuthenticationProvider;
	}
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(AuthenticationProvider());
	}
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		    .authorizeRequests()
		    .antMatchers("/doctor/**","/Pharmeasy/**","/addToCart","/search"
		    		,"/showNewMedicineForm","/viewAllMedicine","/addMotherBabyCare"
		    		,"/saveMotherBabyCare","/viewAllBabyProduct").hasRole("ADMIN")
		    .antMatchers("/Pharmeasy/**","/addToCart","/search").hasRole("USER")
		    .antMatchers("/public/**","/baymedicine/**","/all-user/**","/Prescription").permitAll()
		    .and().formLogin()
		    .loginPage("/baymedicine/loging")		  
		    .defaultSuccessUrl("/Pharmeasy/medicine")
		    .and().csrf().disable();
		     
	}
}
