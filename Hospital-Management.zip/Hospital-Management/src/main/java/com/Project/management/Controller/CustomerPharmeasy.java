package com.Project.management.Controller;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Project.management.Entity.Medicine;
import com.Project.management.Entity.MotherBabyCare;
import com.Project.management.Rapository.BabyProductRepository;
import com.Project.management.Rapository.MedicineRepository;
import com.Project.management.Service.BabyProductService;
import com.Project.management.Service.MedicineService;

@Controller
@RequestMapping("/Pharmeasy")
public class CustomerPharmeasy {

	@Autowired
	private MedicineService medicineService;
	
	@Autowired
	private BabyProductService babyProductService;

	@Autowired
	private MedicineRepository medicineRepository;
	
//	@Autowired
//	private Medicine medicine;
	
	@Autowired
	private BabyProductRepository repo;

	@GetMapping("/medicine")
	public String viewAllMedicine(Model m, Principal principal) {

		List<Medicine> allMedicine = this.medicineService.getAllMedicine();
		m.addAttribute("allMedicine", allMedicine);
		m.addAttribute("title", "show all Medicine");
		
		List<MotherBabyCare> allBabyProduct = this.babyProductService.getAllBabyProduct();
		m.addAttribute("allBabyProduct", allBabyProduct);
		m.addAttribute("title", "show all Medicine");
		return "medicine";
	}

	@GetMapping("/view-one-medicin/{medicinid}")
	public String viewMedicine(@PathVariable("medicinid") long medicinid, Model m, Principal principal) {

		List<Medicine> allMedicine = this.medicineService.getAllMedicine();
		m.addAttribute("allMedicine", allMedicine);
		m.addAttribute("title", "show all Medicine");
		m.addAttribute("link","http://localhost:8585/Pharmeasy/view-one-medicin/"+medicinid);
		
		
		Optional<Medicine> getone = this.medicineRepository.findById(medicinid);
		Medicine medicine = getone.get();
		m.addAttribute("medicine", medicine);

		return "single_Pharmeasy_Medicine";
	}
	
	@GetMapping("/view-single-babyproduct/{babyproductId}")
	public String showOneMotherBaby(@PathVariable("babyproductId") long babyproductId, Model m) {

		Optional<MotherBabyCare> getone = this.repo.findById(babyproductId);
		MotherBabyCare oneBabyProduct = getone.get();
		m.addAttribute("oneBabyProduct", oneBabyProduct);

		return "single_Pharmeasy_BabyProduct";
	}
	
	@GetMapping("/onlymedicine")
	public String viewAllOnlyMedicine(Model m, Principal principal) {

		List<Medicine> allMedicine = this.medicineService.getAllMedicine();
		m.addAttribute("allMedicine", allMedicine);
		m.addAttribute("title", "show all Medicine");
		return "onlymedicine";
	}
	@GetMapping("/onlyBabyProdact")
	public String viewAllOnlyMotherBaby(Model m, Principal principal) {

		List<MotherBabyCare> allBabyProduct = this.babyProductService.getAllBabyProduct();
		m.addAttribute("allBabyProduct", allBabyProduct);
		m.addAttribute("title", "show all Medicine");
		return "onlyBabyProdact";
	}
}
