package com.Project.management.Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Project.management.Entity.BloodTest;
import com.Project.management.Helper.Massage;
import com.Project.management.Service.BloodTestService;

@Controller
@RequestMapping("/all-user")
public class AllUser {

	@Autowired
	private BloodTestService bloodTestService;

	@RequestMapping("/free-checkups")
	public String freecheckups() {
		return "free-checkups";
	}

	@RequestMapping("/ambulance")
	public String freeambulance() {
		return "ambulance";
	}

	@RequestMapping("/bed-facility")
	public String bedfacility() {
		return "bedfacility";
	}

	@RequestMapping("/lab")
	public String lab() {
		return "lab";
	}

	@GetMapping("/home-collection")
	public String registration(Model model) {

		return "home-collection";
	}

	@PostMapping("/saveBloodTest")
	public String saveBookingBloodTest(@ModelAttribute("BloodTest") BloodTest bloodTest, HttpSession session) {
		// save employee to database
		if (bloodTest == null) {
			session.setAttribute("message", new Massage("Successfilly Register !!", "alart-danger"));
			return "redirect:/all-user/home-collection";
		} else {
			try {
				bloodTestService.saveBloodTestBooking(bloodTest);
				session.setAttribute("message", new Massage("Successfilly Register !!", "alart-success"));
			} catch (Exception e) {
				e.printStackTrace();
				session.setAttribute("message", new Massage("Somthing went wring !!" + e.getMessage(), "alert-denger"));
			}
			return "redirect:/all-user/home-collection";
		}
	}
}
