package com.Project.management.Service;

import com.Project.management.Entity.BloodTest;

public interface BloodTestService {

	void saveBloodTestBooking(BloodTest bloodTest);
	
}
