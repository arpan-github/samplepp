package com.Project.management.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "medicine")
public class Medicine {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long medicinid;

	private String medicinename;

	private Double medicineprice;

	private String medicineabout;

	private String image;

	private int medicinDiscount;

	@ManyToOne
	private User user;

	public long getMedicinid() {
		return medicinid;
	}

	public void setMedicinid(long medicinid) {
		this.medicinid = medicinid;
	}

	public String getMedicinename() {
		return medicinename;
	}

	public void setMedicinename(String medicinename) {
		this.medicinename = medicinename;
	}

	public Double getMedicineprice() {
		return medicineprice;
	}

	public void setMedicineprice(Double medicineprice) {
		this.medicineprice = medicineprice;
	}

	public String getMedicineabout() {
		return medicineabout;
	}

	public void setMedicineabout(String medicineabout) {
		this.medicineabout = medicineabout;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Medicine(long medicinid, String medicinename, Double medicineprice, String medicineabout, String image,
			User user) {
		super();
		this.medicinid = medicinid;
		this.medicinename = medicinename;
		this.medicineprice = medicineprice;
		this.medicineabout = medicineabout;
		this.image = image;
		this.user = user;
	}

	public Medicine() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getMedicinDiscount() {
		return medicinDiscount;
	}

	public void setMedicinDiscount(int medicinDiscount) {
		this.medicinDiscount = medicinDiscount;
	}

	public int MedicineDiscount() {
		int d = (int) ((this.getMedicinDiscount()/100.0)*this.getMedicineprice());
		return (int) (this.getMedicineprice() - d);
	}
}
