package com.Project.management.Controller;

import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Project.management.Service.ShoppingCartService;

@Controller
public class CardController {

	@Autowired
	private ShoppingCartService shoppingCartService;
	
	@GetMapping("/payment-option")
	public String payment() {
		
		return "payment_option";
	}
	@GetMapping("/shipping-adderss/hvdu78vnbf990bv3vs5b5")
	public String paymentadderss() {
		
		return "shipping_adderss";
	}

	@PostMapping("/addToCart")
	public String addToCart(HttpSession session, Model model, @RequestParam("id") Long id,
			@RequestParam("quantity") int quantity) {

		// sessiontToken
		String sessionToken = (String) session.getAttribute("sessiontToken");
		if (sessionToken == null) {

			sessionToken = UUID.randomUUID().toString();
			session.setAttribute("sessionToken", sessionToken);
			shoppingCartService.addShoppingCartFirstTime(id, sessionToken, quantity);

		} else {
			shoppingCartService.addToExistingShoppingCart(id, sessionToken, quantity);
		}
		return "card";
	}

}
