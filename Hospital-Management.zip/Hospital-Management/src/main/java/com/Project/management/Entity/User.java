package com.Project.management.Entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long usreId;
	@NotBlank(message = "name not be blank")
	@Size(min = 2, max = 20, message = "min 2 and max 20 characters are allowed !!")
	private String firstName;
	@NotBlank(message = "Title not be blank")
	private String lastName;
	@NotBlank(message = "Email not be blank")
	private String email;
	@NotBlank(message = "password not be blank")
	private String password;
	private String roll;
	private boolean enabled;
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Medicine> medicine = new ArrayList<>();
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<CartItem> cartItem = new ArrayList<>();

	public Long getUsreId() {
		return usreId;
	}

	public void setUsreId(Long usreId) {
		this.usreId = usreId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRoll() {
		return roll;
	}

	public void setRoll(String roll) {
		this.roll = roll;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public List<Medicine> getMedicine() {
		return medicine;
	}

	public void setMedicine(List<Medicine> medicine) {
		this.medicine = medicine;
	}

	public List<CartItem> getCartItem() {
		return cartItem;
	}

	public void setCartItem(List<CartItem> cartItem) {
		this.cartItem = cartItem;
	}
	public User(Long usreId,
			@NotBlank(message = "name not be blank") @Size(min = 2, max = 20, message = "min 2 and max 20 characters are allowed !!") String firstName,
			@NotBlank(message = "Title not be blank") String lastName,
			@NotBlank(message = "Email not be blank") String email,
			@NotBlank(message = "password not be blank") String password, String roll, boolean enabled,
			List<Medicine> medicine) {
		super();
		this.usreId = usreId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.roll = roll;
		this.enabled = enabled;
		this.medicine = medicine;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

}
