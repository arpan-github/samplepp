package com.Project.management.Controller;

import java.security.Principal;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Project.management.Entity.User;
import com.Project.management.Helper.Massage;
import com.Project.management.Rapository.UserRepository;
import com.Project.management.Service.UserService;

@Controller
@RequestMapping("/baymedicine")
public class LogingForMedicine {

	@Autowired
	private UserService userService;

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@GetMapping("/loging")
	public String loging() {
		return "loging_form_user";
	}

	@GetMapping("/registration")
	public String registration(Model model) {
		// create model attribute to bind form data
		User user = new User();
		model.addAttribute("user", user);
		return "registration_form_user";
	}

	@PostMapping("/saveUser")
	public String saveMedicine(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
		if (user.getEmail() == null) {

			session.setAttribute("message", new Massage("Successfilly Register !!", "alart-danger"));
			return "redirect:/baymedicine/registration";
		} else {
			user.setRoll("ROLE_USER");
			user.setEnabled(true);
			user.setPassword(passwordEncoder.encode(user.getPassword()));

			userService.userData(user);

			session.setAttribute("message", new Massage("Successfilly Register !!", "alart-success"));
			return "redirect:/baymedicine/loging";
		}
	}

	@GetMapping("/forget-password")
	public String forget() {
		return "forget_password";
	}

	@PostMapping("/changepassword")
	public String change(@RequestParam("oldpassword") String oldpassword,
			@RequestParam("newpassword") String newpassword,Principal p,User u) {
		System.out.println(oldpassword);
		System.out.println(newpassword);
		
		String username = p.getName();
		User curentuser = userRepository.getUserByUserName(username);
		System.out.println(curentuser);
		
		return "redirect:/baymedicine/loging";
	}
}
