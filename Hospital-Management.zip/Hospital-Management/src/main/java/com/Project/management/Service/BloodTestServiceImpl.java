package com.Project.management.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.management.Entity.BloodTest;
import com.Project.management.Rapository.BloodTestRepository;

@Service
public class BloodTestServiceImpl implements BloodTestService {

	@Autowired
	private BloodTestRepository bloodTestRepository;

	@Override
	public void saveBloodTestBooking(BloodTest bloodTest) {
		this.bloodTestRepository.save(bloodTest);
	}

}
