package com.Project.management.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PatientPrescription {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long patientprescriptionId;
	private String doctorname;
	private String patientname;
	private String department;
	private String sex;
	private String age;
	private String date;
	private String symptoms;
	private String tests;
	private String advice;
	private String prescribemedicine;

	
	public long getPatientprescriptionId() {
		return patientprescriptionId;
	}
	public void setPatientprescriptionId(long patientprescriptionId) {
		this.patientprescriptionId = patientprescriptionId;
	}
	public String getDoctorname() {
		return doctorname;
	}
	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}
	public String getPatientname() {
		return patientname;
	}
	public void setPatientname(String patientname) {
		this.patientname = patientname;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getSymptoms() {
		return symptoms;
	}
	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}
	public String getTests() {
		return tests;
	}
	public void setTests(String tests) {
		this.tests = tests;
	}
	public String getAdvice() {
		return advice;
	}
	public void setAdvice(String advice) {
		this.advice = advice;
	}
	public String getPrescribemedicine() {
		return prescribemedicine;
	}
	public void setPrescribemedicine(String prescribemedicine) {
		this.prescribemedicine = prescribemedicine;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
}
