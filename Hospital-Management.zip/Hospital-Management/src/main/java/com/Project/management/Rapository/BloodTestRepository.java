package com.Project.management.Rapository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Project.management.Entity.BloodTest;

@Repository
public interface BloodTestRepository extends JpaRepository<BloodTest, Long>{

}
