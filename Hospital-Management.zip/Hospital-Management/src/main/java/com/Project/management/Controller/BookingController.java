package com.Project.management.Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Project.management.Entity.Booking;
import com.Project.management.Helper.Massage;
import com.Project.management.Service.BookingService;

@Controller
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@GetMapping("/showbookingForm")
	public String showBookingForm(Model model) {

		Booking booking = new Booking();
		model.addAttribute("booking", booking);
		return "appointment";
	}

	@PostMapping("/saveBooking")
	public String saveBooking(@RequestParam("name") String name, @RequestParam("department") String department,
			@RequestParam("name") String date, @ModelAttribute("booking") Booking booking, HttpSession session,
			Model m) {
		// save employee to database
		if (booking == null) {
			session.setAttribute("message", new Massage("Successfilly Register !!", "alart-danger"));
			return "redirect:/showbookingForm";
		} else {
			try {
				bookingService.saveBooking(booking);
				session.setAttribute("message", new Massage("Successfilly Register !!", "alart-success"));
				System.out.println(name);
				m.addAttribute("name", name);
				m.addAttribute("department", department);
				m.addAttribute("date", date);
			} catch (Exception e) {
				e.printStackTrace();
				session.setAttribute("message", new Massage("Somthing went wring !!" + e.getMessage(), "alert-denger"));
			}
			return "redirect:/showbookingForm";
		}
	}
}
