let menu = document.querySelector('#menu-btn');
let navbar = document.querySelector('.navbar');

menu.onclick = () => {
	menu.classList.toggle('fa-times');
	navbar.classList.toggle('active');
}

window.onscroll = () => {
	menu.classList.remove('fa-times');
	navbar.classList.remove('active');
}
/*
//search
const search=()=>{
	console.log("searching...");
	
	let query=$("#search-input").val();
	
	if(query==""){
		$(".search-result").hide();
	}else{
		console.log(query);
		let url=`http://localhost:8585/search/${query}`;

		fetch(url)
		.then((response)=>{
			return response.json();
		}).then((data)=>{
			console.log(data);
			let text=`<div class='list-group'>`;
			data.forEach((medicine) => {
				text+=`<a href='/Pharmeasy/view-one-medicin/${medicine.medicinid}' class='list-group-item list-group-action'>${medicine.medicinename}</a>`
			});
			text +=`</div>`;

			$(".search-result").html(text);
			$(".search-result").show();
		});
		$(".search-result").show();
	}
}
*/
/*
function add_to_cart(medicinid,medicinename,medicineprice,medicineabout)
{
  let cart=localStorage.getItem("cart");
  if(cart==null)
  {
    //no card add
    let medicins=[];
	let medicin={medicinId:medicinid,medicineName:medicinename,medicinePrice:medicineprice,medicineAbout:medicineabout,medicineQuentity:1}
    medicins.push(medicin);
  }else{
     //allrady avalable


  }
}*/

